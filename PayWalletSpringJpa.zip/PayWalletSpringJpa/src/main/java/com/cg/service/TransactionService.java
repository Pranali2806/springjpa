/*
 * Validates Account holders information,performs insert and display account holders information  to collection,
 */
package com.cg.service;
public class TransactionService implements ITransactionService {

	
	public boolean validateAmount(String amount) {
		if (amount.matches(accountIdPattern)) {
			return true;
		} else {
			return false;
		}
	}

	
	public boolean validateAccountId(String holderAccountId) {
		if (holderAccountId.matches(accountIdPattern)) {
			return true;
		} else {
			return false;
		}
	}

}
