package com.cg.service;

public interface ITransactionService {
	boolean validateAmount(String amount);
	boolean validateAccountId(String holderAccountId);
	String accountIdPattern="[0-9]{1,}";
	String amountPattern="[0-9]{1,}";
}
