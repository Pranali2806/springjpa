/*
 * Validates Account holders information,performs insert and display account holders information  to collection,
 */
package com.cg.service;

import java.util.List;
import com.cg.entity.Account;
import com.cg.entity.Transaction;
import com.cg.repo.AccountRepo;
import com.cg.repo.AccountRepoImpl;
import com.cg.exception.InvalidException;

public class AccountService implements IAccountService {
	AccountRepo ad = new AccountRepoImpl();
	
	public boolean validateHolderName(String holderName) {
		if(holderName.matches(holderNamePattern)) {
			return true;
		} else {
			return false;
		}
	}

	
	public boolean validateHolderAddress(String holderAddress) {
		if (holderAddress.matches(holderAddressPattern)) {
			return true;
		} else {
			return false;
		}
	}

	
	public boolean validateHolderEmail(String holderEmail) {
		if (holderEmail.matches(holderEmailPattern)) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean validateHolderMobileNo(String holderMobileNo) {
		if (holderMobileNo.matches(mobileNumberPattern)) {
			return true;
		} else {
			return false;
		}
	}

	
	public void createAccount(Account acct) {
		ad.createAccount(acct);	
	}

	
	public void deposit(double amount, int accountId)  throws InvalidException {
		ad.deposit(amount, accountId);	
	}
	
	public void withdraw(Double amount, int accountId) throws InvalidException {
		ad.withdraw(amount, accountId);	
	}
	
	public double showBalance(int accountId)throws InvalidException {
		return ad.showBalance(accountId);
	}
	public void getDetailsById(int acctId){
		ad.getDetailsById(acctId);
	}

	
	public List<Transaction> showTransaction(int accountId) {
		return ad.showTransaction(accountId);
	}

	
	public void fundTransfer(int scourceAcctId, int destAcctId, double amount)
			throws InvalidException {
		ad.fundTransfer(scourceAcctId,destAcctId,amount);
	}
}
