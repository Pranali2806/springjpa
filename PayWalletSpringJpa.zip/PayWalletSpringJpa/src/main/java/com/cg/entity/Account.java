package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank")
public class Account implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(length=20)
	private int accountId;
	@Column(length=20)
	private String holderName;
	@Column(length=20)
	private String holderAddress;
	@Column(length=20)
	private long holderMobileNumber; 
	@Column(length=20)
	private String holderEmail;
	@Column(length=20)
	private double MIN_BALANCE = 1000;
	@Column(length=20)
	private double balance;
	public Account(){	
		balance = MIN_BALANCE;
	}
	public double getMIN_BALANCE() {
		return MIN_BALANCE;
	}
	public void setMIN_BALANCE(double mIN_BALANCE) {
		MIN_BALANCE = mIN_BALANCE;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public String getHolderAddress() {
		return holderAddress;
	}
	public void setHolderAddress(String holderAddress) {
		this.holderAddress = holderAddress;
	}
	public long getHolderMobileNumber() {
		return holderMobileNumber;
	}
	public void setHolderMobileNumber(long holderMobileNumber) {
		this.holderMobileNumber = holderMobileNumber;
	}
	public String getHolderEmail() {
		return holderEmail;
	}
	public void setHolderEmail(String holderEmail) {
		this.holderEmail = holderEmail;
	}
	@Override
	public String toString() {
		return "Account Id=" + accountId + ",\nHolder name=" + holderName
				+ ",\nHolder address=" + holderAddress + ",\nHolder Mobile No.="
				+ holderMobileNumber + ",\nHolder email id=" + holderEmail
				+ ",\nMinimum balance=" + MIN_BALANCE + ",\nBalance=" + balance;
	}
	
}
