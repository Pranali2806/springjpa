package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="transaction")
public class Transaction {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int transactionId;
	@Column(length=20)
	private int accountId;
	@Column(length=20)
	private String type;
	@Column(length=20)
	private double amount;
	@Column(length=20)
	private double balance;
	public Transaction(){
		
	}
	public Transaction(int accountId, String type, double amount, double balance) {
		this.accountId = accountId;
		this.type = type;
		this.amount = amount;
		this.balance = balance;
	}
	public String print(){
		return type + "\t" + amount + "\t" + balance;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Transaction [type=" + type + ", amount=" + amount
				+ ", balance=" + balance + "]";
	}
}
