package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Account;
import com.cg.entity.Transaction;
import com.cg.exception.InvalidException;

@Repository
public class AccountRepoImpl implements AccountRepo {

	double previousBalance;
	
	@PersistenceContext(unitName ="JPA-PU")
	private EntityManager em;
	
	@Transactional(propagation=Propagation.REQUIRED)
	public void createAccount(Account acct) {
		em.persist(acct);
		System.out.println("Added one account to database.");
	}

	@Transactional(propagation=Propagation.SUPPORTS)
	public void getDetailsById(int acctId) {
		Account acct =  em.find(Account.class, acctId);
		System.out.println(acct);
	}
	
	@Transactional
	public void deposit(double amount, int accountId) throws InvalidException {
		Account acct =  em.find(Account.class, accountId);
		if (acct!=null) {
		previousBalance = acct.getBalance();
		acct.setBalance(previousBalance + amount);
		em.merge(acct);
		Transaction trans = new Transaction(accountId, "CR", amount, (previousBalance + amount));
		em.persist(trans);
		System.out.println("deposit successful");
		} else {
			throw new InvalidException("Accound does not exists");
		}
	}

	@Transactional
	public void withdraw(Double amount, int accountId) throws InvalidException {
		Account acct = em.find(Account.class, accountId);
		if (acct!=null) {
			double amt = acct.getBalance();
			if (amount <= amt) { // checks if amount entered by user is less then total balance
				acct.setBalance(amt - amount);
				em.merge(acct);
				Transaction trans = new Transaction(accountId ,"DB", amount, (amt - amount));
				em.persist(trans);
				System.out.println("withdraw successful");
			} else {
				throw new InvalidException("Insufficient Balance");
			}
		} else {
			throw new InvalidException("Accound does not exists");
		}
	}

	@Transactional
	public double showBalance(int accountId) throws InvalidException {
		
		Account acct = em.find(Account.class, accountId);
		if (acct!=null) {
			return acct.getBalance();
		} else {
			throw new InvalidException("Account does not exists");
		}
	}

	@Transactional
	public List<Transaction> showTransaction(int accountId) {
		return em.createQuery("from Product").getResultList();
	}

	@Transactional
	public void fundTransfer(int scourceAcctId, int destAcctId, double amount) throws InvalidException {
		withdraw(amount, scourceAcctId);
		deposit(amount,destAcctId);
	}



}
