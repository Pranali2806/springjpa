package com.cg.repo;

import java.util.List;

import com.cg.entity.Account;
import com.cg.entity.Transaction;
import com.cg.exception.InvalidException;

public interface AccountRepo {
	public void createAccount(Account acct); // create
	public void getDetailsById(int acctId); // find
	void deposit(double amount, int accountId) throws InvalidException; //deposit
	public void withdraw(Double amount, int accountId) throws InvalidException; //withdraw
	double showBalance(int accountId) throws InvalidException; //show balance
	public List<Transaction> showTransaction(int accountId); // show transactions
	void fundTransfer(int scourceAcctId, int destAcctId, double amount) throws InvalidException; //fund transfer
}
